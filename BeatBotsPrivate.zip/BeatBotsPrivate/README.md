# beat-bots
A hand gesture controlled drumming experience.
